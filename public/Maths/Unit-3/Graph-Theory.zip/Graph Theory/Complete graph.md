---
has_equation: $\frac{n(n-1)}{2}$
---

>[!cite] Complete Graph
>A [[Simple Graph]] that is connected to every other [[Vertex]] by an edge. The complete graph with n vertices is denoted as $K_n$

#### Finding Edges on Complete graph
A complete graph with n verticies has
$$\frac{n(n-1)}{2}$$
edges