>[!cite] Connected Graph
>A connected graph is a graph where every vertex is indirectly or directly connected to every other vertex, a.k.a from any vertex it is possible to travel across the edges to reach any other vertex either indirectly or directly.

### Example
##### Connected
![](https://i.imgur.com/SmTMdYC.png)
