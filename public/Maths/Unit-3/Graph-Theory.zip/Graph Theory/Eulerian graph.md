---
banner: "https://i.imgur.com/2ZhlMEr.png"
---
### Definition
>[!cite] Eulerian Graph
>A Eulerian graph is a graph which contains a [[Eulerian Cycle]].
>A Semi-Eulerian graph contains a [[Semi-Eulerian Trail]].
> 
><hr>
>
>A **Eulerian Cycle** exists if the *graph* has 0 [[Vertex#Odd Vertex|Odd Vertices]], 
>A **Semi-Eulerian Trail** exists if the *graph* has 2 [[Vertex#Odd Vertex|Odd Verticies]].
>*Eulerian* and *semi-eulerian* Graphs are **[[Traversable Graphs|Traversable]]**. meaning we can traverse them using each edge only once.

- Eulerian Graphs
	- Are Traversable
	- Are Closed (Start and end at the same vertex)
- Semi-Eulerian Graphs
	- Are Traversable
	- Are Open (Start and end at different verticies)


>[!warning]
>Mr. Acott will mark wrong if don't say that a graph is eulerian **because** it contains a [[Eulerian Trail]].

#check - In a **non-eulerian** graph you end at the other odd vertex



