>[!cite] Simple Graph
>A Simple graph *does not have*, loops, mutliple edges, directions or weights.

Multiple edges = only one edge between each vertex

If the simple graph is [[Complete graph|complete]], you can find the amount of edges with this formula;
![[Complete graph#Finding Edges on Complete graph|clean no-h border]]