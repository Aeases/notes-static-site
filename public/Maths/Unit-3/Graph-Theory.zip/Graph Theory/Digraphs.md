---
aliases: Directed Graph
banner: "https://i.imgur.com/GJVcnIB.png"
---
>[!cite] Digraph
>A digraph is a graph with direction



