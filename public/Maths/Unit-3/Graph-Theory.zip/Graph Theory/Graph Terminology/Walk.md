A walk is when you go from node to node

#review - Add Diagrams
#### Open Walk
A *Open Walk* is a walk where you end off at a different [[Vertex]] to the one that you started off at.
#### Closed Walk
A Closed walk is when you return back to the [[Vertex]] at which you started.