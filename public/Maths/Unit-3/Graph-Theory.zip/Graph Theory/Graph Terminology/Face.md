---
banner: "https://i.imgur.com/DwlP0Gv.png"
banner_y: 0.5
---
### Definition
>[!cite] Face
A Face of a graph is any area that is enclosed by [[Edge]]s
