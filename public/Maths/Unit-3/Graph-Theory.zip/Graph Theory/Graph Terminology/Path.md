### Defintion
>[!cite] Path
>A path is a [[Walk]] in which all the edges and al the vertices are different.

A path can never contain any [[Loop]]s since by definition a loop *requires* repeating a [[Vertex]].

#### Closed Path
A path that begins/ends with the same vertex, this is the **same thing** as a [[Cycle]]