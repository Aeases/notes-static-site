---
aliases: Adjacent
---


>[!cite] Adjacent (Graphs)
>[[Vertex|Verticies]] are *Adjacent* to one another if there is an [[Edge]] that **directly** connects them.


