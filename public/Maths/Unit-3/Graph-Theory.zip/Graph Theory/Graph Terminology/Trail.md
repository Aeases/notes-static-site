### Definition
>[!cite] Trail
>A Trail is a [[Walk]] where no [[edge]] has been repeated.
>
Different from cycles since a trail can't repeat [[Vertex|Verticies]] or [[Edge]]s. where as a Trail can only not repeat [[Edge]]s

#### Open Trail
Begins at one [[Vertex]] and ends at a different [[Vertex]].

#### Closed Trail
A Trail that ends at the same [[Vertex]] you started at. 
>[!warning] review this
#review 
