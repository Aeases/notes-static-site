>[!cite] Bridge
>An edge were if it removed the graph is no longer connected.

