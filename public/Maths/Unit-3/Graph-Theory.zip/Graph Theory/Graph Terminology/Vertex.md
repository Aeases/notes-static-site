---
aliases: Verticies, Node
banner: "https://i.imgur.com/zWdumYe.png"
---


>[!cite] Vertex / Verticies / Node
>A **Vertex** is a point or node on a graph, they are usually connected by [[Edge]]s / [[Edge|Arc]]s

#### Odd Vertex
A Vertex is odd when its [[degree of a vertex|Degree]] is a odd number
