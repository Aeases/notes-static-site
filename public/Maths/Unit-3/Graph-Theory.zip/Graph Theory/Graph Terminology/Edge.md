---
aliases: Arc
banner: "https://i.imgur.com/WtqXOR9.png"
---

>[!cite] Edge / Arc
>An Edge is a connection between verticies