---
banner: "https://i.imgur.com/1Aottl9.png"
---



#review
### Definition
>[!cite] Subgraphs
>A *subgraph* is a graph that can be '*extracted*' from another graph,


### Examples
![](https://i.imgur.com/1Aottl9.png)
