### Definition
>[!cite] The shortest Path
>The shortest path with a graph with **weighted edges**.



>[!example]-
![](https://i.imgur.com/e00hTG8.png)
Using trial and error we can determine HBM is the shortest

![[Shortest Walk Example.excalidraw]]
We can do trial and error and work out which one is the best scenario, here it's pretty easy you can see it's a direct line of sight from A to I using *ACDGI*
fsdkgfdjkgdsfk



##### Systemic Approach
Check page 229 in text book

