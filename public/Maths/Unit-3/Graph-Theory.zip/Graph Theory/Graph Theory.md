
#### Components of a graph
>[!faq]- Components of a Graph
>
>>[!multi-column]
>>
>>>[!blank] 
>>>![[Face|clean|no-title]]
>>
>>>[!blank|wide-5] 
>>>![[Vertex|clean|no-title]]
>>
>>>[!blank] 
>>>![[Edge|clean|no-title]]
>

### Types of Graphs
- [[Bipartite Graphs]]
- [[Directed graph]]
- [[Planar Graph]]
- [[Simple Graph]]
- [[Complete graph]]
- [[Weighted graph]]
- [[Connected Graph]]


