>[!cite] Not Simple Graph
>A graph that contains any of the following: Multiple Edges, Loops, [[Digraphs]], Weights.