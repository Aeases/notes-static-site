---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
Directed Graph ^iJVb9CIy

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.22",
	"elements": [
		{
			"type": "ellipse",
			"version": 354,
			"versionNonce": 947832852,
			"isDeleted": false,
			"id": "SrvNlK2KNxJ0YvosAm6Ju",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -153.3499755859375,
			"y": -191.30788040161133,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 27.3861083984375,
			"height": 27.3861083984375,
			"seed": 666891180,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680784199572,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 460,
			"versionNonce": 709832468,
			"isDeleted": false,
			"id": "EyW8HmbPCMSLBwVIH-WQS",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 81.53863525390625,
			"y": -191.30788040161133,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 27.3861083984375,
			"height": 27.3861083984375,
			"seed": 522290476,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 562,
			"versionNonce": 1221458988,
			"isDeleted": false,
			"id": "MzS-cYBeKyvmM2t_KLzER",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 81.53863525390625,
			"y": -11.542530059814453,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 27.3861083984375,
			"height": 27.3861083984375,
			"seed": 873877908,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 688,
			"versionNonce": 1883253908,
			"isDeleted": false,
			"id": "5uzWEFK6SpFQECgVt7Sge",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -151.59466552734375,
			"y": -11.542530059814453,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 27.3861083984375,
			"height": 27.3861083984375,
			"seed": 2123997844,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false
		},
		{
			"type": "line",
			"version": 51,
			"versionNonce": 1419089580,
			"isDeleted": false,
			"id": "sjUtEHcB3WpJh0xxT282O",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -126.31524658203125,
			"y": -177.26372146606445,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 206.4493408203125,
			"height": 0,
			"seed": 305422100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					206.4493408203125,
					0
				]
			]
		},
		{
			"type": "line",
			"version": 85,
			"versionNonce": 439712276,
			"isDeleted": false,
			"id": "wo8ii58TFKt1IUseTJVUA",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 97.68927001953125,
			"y": -163.21956253051758,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 2.808837890625,
			"height": 152.37924194335938,
			"seed": 1673322644,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-2.808837890625,
					152.37924194335938
				]
			]
		},
		{
			"type": "line",
			"version": 66,
			"versionNonce": 1770381612,
			"isDeleted": false,
			"id": "UBzz1FEAsHCUNeOpF0x_y",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 83.64520263671875,
			"y": 4.608257293701172,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 205.7471923828125,
			"height": 0.70220947265625,
			"seed": 696887188,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-205.7471923828125,
					-0.70220947265625
				]
			]
		},
		{
			"type": "line",
			"version": 43,
			"versionNonce": 1126504340,
			"isDeleted": false,
			"id": "2miVS5zPI4g-RlKooFJu0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -136.84832763671875,
			"y": -11.542530059814453,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 4.2132568359375,
			"height": 151.67703247070312,
			"seed": 803183532,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-4.2132568359375,
					-151.67703247070312
				]
			]
		},
		{
			"type": "line",
			"version": 19,
			"versionNonce": 1057545132,
			"isDeleted": false,
			"id": "IEd8FS4ImUJ0JLI_fzIxI",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -57.49871826171875,
			"y": -176.5615119934082,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 26.6839599609375,
			"height": 14.74639892578125,
			"seed": 605091884,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-26.6839599609375,
					-14.74639892578125
				]
			]
		},
		{
			"type": "line",
			"version": 43,
			"versionNonce": 927270164,
			"isDeleted": false,
			"id": "YPywleqIe4UkJ6OROK95J",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -59.60540771484375,
			"y": -176.5615119934082,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 21.7684326171875,
			"height": 14.746368408203125,
			"seed": 253404844,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-21.7684326171875,
					14.746368408203125
				]
			]
		},
		{
			"type": "line",
			"version": 46,
			"versionNonce": 256411180,
			"isDeleted": false,
			"id": "cq-JfExC0wf8VHySP8PWW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 21.14862060546875,
			"y": -177.26372146606445,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 19.661865234375,
			"height": 11.937530517578125,
			"seed": 1120871212,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-19.661865234375,
					-11.937530517578125
				]
			]
		},
		{
			"type": "line",
			"version": 22,
			"versionNonce": 1275806356,
			"isDeleted": false,
			"id": "YGBzOefNLu6FaF-b6RjbW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 20.44635009765625,
			"y": -175.85930252075195,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 22.4705810546875,
			"height": 11.235321044921875,
			"seed": 1349979796,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-22.4705810546875,
					11.235321044921875
				]
			]
		},
		{
			"type": "line",
			"version": 26,
			"versionNonce": 1060036780,
			"isDeleted": false,
			"id": "HTlVAMzpYeANad-9YRRHL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 95.58270263671875,
			"y": -48.75957107543945,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 21.7684326171875,
			"height": 26.683929443359375,
			"seed": 1174154668,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-21.7684326171875,
					-26.683929443359375
				]
			]
		},
		{
			"type": "line",
			"version": 38,
			"versionNonce": 942526484,
			"isDeleted": false,
			"id": "z70p-UpNtGADHzAj5l_mz",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 94.88043212890625,
			"y": -48.75957107543945,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 24.577392578125,
			"height": 24.577301025390625,
			"seed": 1621251348,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783910917,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					24.577392578125,
					-24.577301025390625
				]
			]
		},
		{
			"type": "line",
			"version": 21,
			"versionNonce": 235570324,
			"isDeleted": false,
			"id": "4UyURKw-W9IvSrmKdfLqT",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 98.39154052734375,
			"y": -92.2964973449707,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 14.044189453125,
			"height": 18.959625244140625,
			"seed": 1805823380,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783912621,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-14.044189453125,
					-18.959625244140625
				]
			]
		},
		{
			"type": "line",
			"version": 21,
			"versionNonce": 1380358060,
			"isDeleted": false,
			"id": "Csvn2IkLazaU_IKPVx0vk",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 100.49810791015625,
			"y": -92.2964973449707,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 14.7464599609375,
			"height": 18.257415771484375,
			"seed": 289193644,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783915485,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					14.7464599609375,
					-18.257415771484375
				]
			]
		},
		{
			"type": "line",
			"version": 97,
			"versionNonce": 1027059884,
			"isDeleted": false,
			"id": "YDqqdDFtUfcNqilgoy60b",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -84.88494873046875,
			"y": 4.608257293701172,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 28.08837890625,
			"height": 16.852996826171875,
			"seed": 1288767764,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783950196,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					28.08837890625,
					-16.852996826171875
				]
			]
		},
		{
			"type": "line",
			"version": 101,
			"versionNonce": 1585623444,
			"isDeleted": false,
			"id": "nqUxqsNwcaC-RFB_9iRKo",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -86.28924560546875,
			"y": 1.7993888854980469,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 30.897216796875,
			"height": 19.661773681640625,
			"seed": 270288300,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783948591,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					30.897216796875,
					19.661773681640625
				]
			]
		},
		{
			"type": "line",
			"version": 51,
			"versionNonce": 1796680492,
			"isDeleted": false,
			"id": "H6VFoh805VZkWIpjfugp0",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -5.53533935546875,
			"y": 3.203838348388672,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 26.6839599609375,
			"height": 15.448577880859375,
			"seed": 1940798612,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783927937,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					26.6839599609375,
					-15.448577880859375
				]
			]
		},
		{
			"type": "line",
			"version": 23,
			"versionNonce": 1784155436,
			"isDeleted": false,
			"id": "WV8FRG6LfKACEfPGs7X64",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -5.53533935546875,
			"y": 3.203838348388672,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 29.4927978515625,
			"height": 16.85296630859375,
			"seed": 564996524,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783925342,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					29.4927978515625,
					16.85296630859375
				]
			]
		},
		{
			"type": "line",
			"version": 56,
			"versionNonce": 2080409492,
			"isDeleted": false,
			"id": "TMy_0J6C7eHDlqwz-iD34",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -141.76385498046875,
			"y": -125.30031204223633,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 33.7059326171875,
			"height": 28.088348388671875,
			"seed": 1407247788,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783930866,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-33.7059326171875,
					28.088348388671875
				]
			]
		},
		{
			"type": "line",
			"version": 36,
			"versionNonce": 768150164,
			"isDeleted": false,
			"id": "2g_yloKbLN-23f2rTRfXs",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -138.95489501953125,
			"y": -126.00252151489258,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 32.301513671875,
			"height": 30.897186279296875,
			"seed": 668756908,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783932717,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					32.301513671875,
					30.897186279296875
				]
			]
		},
		{
			"type": "line",
			"version": 62,
			"versionNonce": 288008980,
			"isDeleted": false,
			"id": "lWAPl6ArbYE-JKe_DtveK",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -141.76385498046875,
			"y": -68.42140579223633,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 21.7684326171875,
			"height": 18.959625244140625,
			"seed": 923900076,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783938397,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-21.7684326171875,
					18.959625244140625
				]
			]
		},
		{
			"type": "line",
			"version": 91,
			"versionNonce": 1128990252,
			"isDeleted": false,
			"id": "YOlIqjMn1x_n9QqNytDDW",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -141.76385498046875,
			"y": -72.63466262817383,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 30.1949462890625,
			"height": 25.279510498046875,
			"seed": 1335906860,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680783942748,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					30.1949462890625,
					25.279510498046875
				]
			]
		},
		{
			"type": "text",
			"version": 128,
			"versionNonce": 853114924,
			"isDeleted": false,
			"id": "iJVb9CIy",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -138.95489501953125,
			"y": -250.29343032836914,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 235.22425842285156,
			"height": 39.04415893554684,
			"seed": 1792326444,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1680783982482,
			"link": null,
			"locked": false,
			"fontSize": 31.235327148437474,
			"fontFamily": 1,
			"text": "Directed Graph",
			"rawText": "Directed Graph",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Directed Graph",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "#000000",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 268.9906695500668,
		"scrollY": 339.6941246263683,
		"zoom": {
			"value": 2
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%