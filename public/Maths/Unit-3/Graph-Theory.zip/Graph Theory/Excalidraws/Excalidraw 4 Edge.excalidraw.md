---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
1 ^rSnD0F3m

Edge ^En9VUI1m

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.22",
	"elements": [
		{
			"type": "ellipse",
			"version": 674,
			"versionNonce": 1586573972,
			"isDeleted": false,
			"id": "4OG5SBqnDuyY0m1u2WDYG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -121.9542236328125,
			"y": -217.1609115600586,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 44.23913574218751,
			"height": 44.23911364326004,
			"seed": 217944236,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680784872067,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 730,
			"versionNonce": 1417220396,
			"isDeleted": false,
			"id": "sjfISESfaBrJDrpe6k2OL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 134.3521728515625,
			"y": -139.91793060302734,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 48.45236206054688,
			"height": 48.45236206054688,
			"seed": 655664532,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680784219833,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 2,
			"versionNonce": 1548831916,
			"isDeleted": false,
			"id": "rSnD0F3m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -59.87896728515625,
			"y": -179.87041091918945,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffffff",
			"width": 5.4199981689453125,
			"height": 25,
			"seed": 827332244,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1680784238906,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1",
			"rawText": "1",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "1",
			"lineHeight": 1.25
		},
		{
			"type": "line",
			"version": 156,
			"versionNonce": 485090452,
			"isDeleted": false,
			"id": "lJONppCiyQo8Gw_dagu6f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -79.96942138671875,
			"y": -183.7921028137207,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 217.6845703125,
			"height": 59.687713623046875,
			"seed": 987022380,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680784255115,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					217.6845703125,
					59.687713623046875
				]
			]
		},
		{
			"type": "arrow",
			"version": 1229,
			"versionNonce": 1542915476,
			"isDeleted": false,
			"id": "FfbVKRvroF9T-LM-YTIZX",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"angle": 0,
			"x": 27.681715375490796,
			"y": -238.37514317372035,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 52.52778471142841,
			"height": 61.95623982289027,
			"seed": 141864492,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680784896870,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "arrow",
			"points": [
				[
					0,
					0
				],
				[
					-47.61237943799076,
					23.334764603163705
				],
				[
					-52.52778471142841,
					61.95623982289027
				]
			]
		},
		{
			"type": "text",
			"version": 644,
			"versionNonce": 1868334636,
			"isDeleted": false,
			"id": "En9VUI1m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 25.3619384765625,
			"y": -261.3860511779785,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 79.26856994628906,
			"height": 43.257415771484354,
			"seed": 1646571436,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1680784878773,
			"link": null,
			"locked": false,
			"fontSize": 34.605932617187484,
			"fontFamily": 1,
			"text": "Edge",
			"rawText": "Edge",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Edge",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "#ffffff",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 2,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 2,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 306.8606255427749,
		"scrollY": 465.05350255145754,
		"zoom": {
			"value": 1.3817572486732046
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%