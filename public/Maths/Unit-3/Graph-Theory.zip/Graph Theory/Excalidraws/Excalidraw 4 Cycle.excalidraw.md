---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
1 ^rSnD0F3m

Cycle ^En9VUI1m

D ^mFUGfkjS

A ^18jpxNPJ

B ^Eklk6xtK

C ^PEl8Kz4f

A  C  B  A ^EPZqe5tF

ACBA ^CM4K4I8M

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.22",
	"elements": [
		{
			"type": "ellipse",
			"version": 687,
			"versionNonce": 163709868,
			"isDeleted": false,
			"id": "4OG5SBqnDuyY0m1u2WDYG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -122.33465576171875,
			"y": -217.1609115600586,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 45,
			"height": 49,
			"seed": 217944236,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "Eklk6xtK"
				},
				{
					"id": "b9L_2c1NU30xxmyDDjBmb",
					"type": "arrow"
				},
				{
					"id": "aHVyZGt1ieyuzkcIUp5uU",
					"type": "arrow"
				}
			],
			"updated": 1680786636157,
			"link": null,
			"locked": false
		},
		{
			"id": "Eklk6xtK",
			"type": "text",
			"x": -107.01455498148248,
			"y": -204.985027699129,
			"width": 14.539993286132812,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1137625644,
			"version": 8,
			"versionNonce": 796727188,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"text": "B",
			"rawText": "B",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "4OG5SBqnDuyY0m1u2WDYG",
			"originalText": "B",
			"lineHeight": 1.25
		},
		{
			"type": "ellipse",
			"version": 745,
			"versionNonce": 318983212,
			"isDeleted": false,
			"id": "nDPFG1GT6XxNBVqBgBoe3",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 134.07835388183594,
			"y": -139.91793060302734,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 49,
			"height": 49,
			"seed": 1205428884,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "PEl8Kz4f"
				},
				{
					"id": "b9L_2c1NU30xxmyDDjBmb",
					"type": "arrow"
				},
				{
					"id": "bDpNQMKgLcTa0-oizlOuG",
					"type": "arrow"
				}
			],
			"updated": 1680786534911,
			"link": null,
			"locked": false
		},
		{
			"id": "PEl8Kz4f",
			"type": "text",
			"x": 152.3142429307538,
			"y": -127.74204674209776,
			"width": 12.879989624023438,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1240742188,
			"version": 8,
			"versionNonce": 1486685460,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"text": "C",
			"rawText": "C",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "nDPFG1GT6XxNBVqBgBoe3",
			"originalText": "C",
			"lineHeight": 1.25
		},
		{
			"type": "text",
			"version": 5,
			"versionNonce": 1332774444,
			"isDeleted": false,
			"id": "rSnD0F3m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -59.87896728515625,
			"y": -179.87041091918945,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffffff",
			"width": 5.4199981689453125,
			"height": 25,
			"seed": 827332244,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1",
			"rawText": "1",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "1",
			"lineHeight": 1.25
		},
		{
			"type": "line",
			"version": 159,
			"versionNonce": 40059540,
			"isDeleted": false,
			"id": "lJONppCiyQo8Gw_dagu6f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -79.96942138671875,
			"y": -183.7921028137207,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 217.6845703125,
			"height": 59.687713623046875,
			"seed": 987022380,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					217.6845703125,
					59.687713623046875
				]
			]
		},
		{
			"type": "text",
			"version": 983,
			"versionNonce": 1669713940,
			"isDeleted": false,
			"id": "En9VUI1m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -100.7712040694814,
			"y": -387.5878550322058,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "#ffffff",
			"width": 83.90495300292969,
			"height": 43.257415771484354,
			"seed": 1646571436,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"fontSize": 34.605932617187484,
			"fontFamily": 1,
			"text": "Cycle",
			"rawText": "Cycle",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Cycle",
			"lineHeight": 1.25
		},
		{
			"type": "line",
			"version": 162,
			"versionNonce": 1552804652,
			"isDeleted": false,
			"id": "TxNhKbTrm_KXfkdhAj0Oc",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"angle": 0,
			"x": 156.04373670367892,
			"y": -140.58152146132244,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 54.377389813739114,
			"height": 132.1319058939709,
			"seed": 1419957932,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					-54.377389813739114,
					-132.1319058939709
				]
			]
		},
		{
			"type": "ellipse",
			"version": 892,
			"versionNonce": 1568305708,
			"isDeleted": false,
			"id": "sjfISESfaBrJDrpe6k2OL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 72.00420061722559,
			"y": -310.6729722922383,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 40,
			"height": 49,
			"seed": 655664532,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "18jpxNPJ"
				},
				{
					"id": "bDpNQMKgLcTa0-oizlOuG",
					"type": "arrow"
				},
				{
					"id": "aHVyZGt1ieyuzkcIUp5uU",
					"type": "arrow"
				}
			],
			"updated": 1680786632486,
			"link": null,
			"locked": false
		},
		{
			"id": "18jpxNPJ",
			"type": "text",
			"x": 85.30206743490089,
			"y": -298.4970884313087,
			"width": 13.1199951171875,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1343888172,
			"version": 8,
			"versionNonce": 1753195948,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"text": "A",
			"rawText": "A",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "sjfISESfaBrJDrpe6k2OL",
			"originalText": "A",
			"lineHeight": 1.25
		},
		{
			"type": "line",
			"version": 122,
			"versionNonce": 486005524,
			"isDeleted": false,
			"id": "MHZieau-yDxsOsAC58KqC",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"angle": 0,
			"x": -85.3511049632684,
			"y": -214.6203859135374,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 157.5419217752166,
			"height": 68.60691036298334,
			"seed": 889023532,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					157.5419217752166,
					-68.60691036298334
				]
			]
		},
		{
			"type": "ellipse",
			"version": 955,
			"versionNonce": 2123804588,
			"isDeleted": false,
			"id": "v5T96D5mpEbGBcH6NM1lv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 220.8561831759746,
			"y": -252.9285775387519,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 49,
			"height": 49,
			"seed": 1816210604,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"type": "text",
					"id": "mFUGfkjS"
				}
			],
			"updated": 1680786643302,
			"link": null,
			"locked": false
		},
		{
			"id": "mFUGfkjS",
			"type": "text",
			"x": 237.7320716145409,
			"y": -240.75269367782232,
			"width": 15.599990844726562,
			"height": 25,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1803746452,
			"version": 172,
			"versionNonce": 1596879124,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786643302,
			"link": null,
			"locked": false,
			"text": "D",
			"rawText": "D",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "v5T96D5mpEbGBcH6NM1lv",
			"originalText": "D",
			"lineHeight": 1.25
		},
		{
			"id": "6psxQGL03xm0Z5k_d1eE_",
			"type": "line",
			"x": 230.34603722776166,
			"y": -207.7260289963618,
			"width": 53.13788915778537,
			"height": 72.88533612106593,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 811335700,
			"version": 202,
			"versionNonce": 524544172,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786647144,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-53.13788915778537,
					72.88533612106593
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "iZWC6w65bLcOZflkQPyfq",
			"type": "line",
			"x": -220.49919900044208,
			"y": -241.49148024819002,
			"width": 119.37542724609375,
			"height": 100.41580200195312,
			"angle": 3.3834876283520146,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1233060244,
			"version": 1575,
			"versionNonce": 1146333100,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786626235,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					76.18789902009377,
					-21.932914905312117
				],
				[
					116.56491318025002,
					37.40363294625038
				],
				[
					57.57937851228127,
					78.48288709664101
				],
				[
					-2.8105140658437335,
					45.12799818062538
				]
			],
			"lastCommittedPoint": [
				-1.7554931640625,
				45.292449951171875
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "bDpNQMKgLcTa0-oizlOuG",
			"type": "arrow",
			"x": 98.22956848144531,
			"y": -261.0263398543598,
			"width": 49.5057373046875,
			"height": 122.88645935058594,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 261061804,
			"version": 549,
			"versionNonce": 1161904556,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786667783,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					49.5057373046875,
					122.88645935058594
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "sjfISESfaBrJDrpe6k2OL",
				"focus": 0.17509613493960272,
				"gap": 1.7422528799651111
			},
			"endBinding": {
				"elementId": "nDPFG1GT6XxNBVqBgBoe3",
				"focus": -0.06395768352454567,
				"gap": 1
			},
			"startArrowhead": null,
			"endArrowhead": "triangle"
		},
		{
			"id": "b9L_2c1NU30xxmyDDjBmb",
			"type": "arrow",
			"x": 134.04212951660156,
			"y": -118.12688001549259,
			"width": 215.57794189453125,
			"height": 55.474456787109375,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 701354132,
			"version": 284,
			"versionNonce": 2133078700,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786661266,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-215.57794189453125,
					-55.474456787109375
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "nDPFG1GT6XxNBVqBgBoe3",
				"focus": -0.14249775820248747,
				"gap": 1
			},
			"endBinding": {
				"elementId": "4OG5SBqnDuyY0m1u2WDYG",
				"focus": 0.5700432289093338,
				"gap": 2.935545188641683
			},
			"startArrowhead": null,
			"endArrowhead": "triangle"
		},
		{
			"id": "aHVyZGt1ieyuzkcIUp5uU",
			"type": "arrow",
			"x": -79.02858447546296,
			"y": -206.86764777882158,
			"width": 150.2984790016646,
			"height": 65.185684430456,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 0.5,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 944965420,
			"version": 453,
			"versionNonce": 464387860,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786667783,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					150.2984790016646,
					-65.185684430456
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "4OG5SBqnDuyY0m1u2WDYG",
				"focus": -0.1965339051089872,
				"gap": 2.105977814427831
			},
			"endBinding": {
				"elementId": "sjfISESfaBrJDrpe6k2OL",
				"focus": -0.1972666196206535,
				"gap": 3.886015874264519
			},
			"startArrowhead": null,
			"endArrowhead": "triangle"
		},
		{
			"id": "CM4K4I8M",
			"type": "text",
			"x": 33.68389747490306,
			"y": -360.67529668142873,
			"width": 56.46881103515625,
			"height": 26.308628073228576,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"WPEOIWxp5jkbCB7xmhnbS"
			],
			"roundness": null,
			"seed": 701959596,
			"version": 294,
			"versionNonce": 354702484,
			"isDeleted": false,
			"boundElements": [
				{
					"id": "6w171MeBc_UxEKC_XTeBD",
					"type": "arrow"
				},
				{
					"id": "XiMAmUaqRPBPB8Rm9nfhg",
					"type": "arrow"
				},
				{
					"id": "pZLaqcXA7PNeMxnB20s5T",
					"type": "arrow"
				}
			],
			"updated": 1680786598667,
			"link": null,
			"locked": false,
			"text": "ACBA",
			"rawText": "ACBA",
			"fontSize": 21.046902458582863,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "ACBA",
			"lineHeight": 1.25
		},
		{
			"id": "EPZqe5tF",
			"type": "text",
			"x": 1.784076605120248,
			"y": -387.0465141029064,
			"width": 119.57022094726562,
			"height": 26.30862807322858,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [
				"WPEOIWxp5jkbCB7xmhnbS"
			],
			"roundness": null,
			"seed": 315087276,
			"version": 428,
			"versionNonce": 1260339092,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786598667,
			"link": null,
			"locked": false,
			"text": "A  C  B  A",
			"rawText": "A  C  B  A",
			"fontSize": 21.046902458582863,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "A  C  B  A",
			"lineHeight": 1.25
		},
		{
			"id": "6w171MeBc_UxEKC_XTeBD",
			"type": "arrow",
			"x": 19.51230248484439,
			"y": -374.24583696823026,
			"width": 13.543315400274643,
			"height": 0.05766035332544561,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [
				"WPEOIWxp5jkbCB7xmhnbS"
			],
			"roundness": {
				"type": 2
			},
			"seed": 1838025516,
			"version": 585,
			"versionNonce": 1771793044,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786598903,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					13.543315400274643,
					0.05766035332544561
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "CM4K4I8M",
				"focus": -1.9996436043085153,
				"gap": 14.171594990058672
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "XiMAmUaqRPBPB8Rm9nfhg",
			"type": "arrow",
			"x": 52.200094656088055,
			"y": -373.6933662945181,
			"width": 13.543315400274643,
			"height": 0.05766035332544561,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [
				"WPEOIWxp5jkbCB7xmhnbS"
			],
			"roundness": {
				"type": 2
			},
			"seed": 463451668,
			"version": 649,
			"versionNonce": 538261676,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680786598903,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					13.543315400274643,
					0.05766035332544561
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "CM4K4I8M",
				"focus": -1.9685085343418374,
				"gap": 13.018069613089352
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "pZLaqcXA7PNeMxnB20s5T",
			"type": "arrow",
			"x": 90.41259356445318,
			"y": -373.6933662945181,
			"width": 13.543315400274643,
			"height": 0.05766035332544561,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "dashed",
			"roughness": 0,
			"opacity": 100,
			"groupIds": [
				"WPEOIWxp5jkbCB7xmhnbS"
			],
			"roundness": {
				"type": 2
			},
			"seed": 594725780,
			"version": 729,
			"versionNonce": 24705044,
			"isDeleted": false,
			"boundElements": [],
			"updated": 1680786598903,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					13.543315400274643,
					0.05766035332544561
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "CM4K4I8M",
				"focus": -1.9807642556075709,
				"gap": 13.018069613089352
			},
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"type": "arrow",
			"version": 2110,
			"versionNonce": 978772140,
			"isDeleted": true,
			"id": "FfbVKRvroF9T-LM-YTIZX",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"angle": 0,
			"x": -36.75463806797404,
			"y": -283.49780842917426,
			"strokeColor": "#343a40",
			"backgroundColor": "#ffffff",
			"width": 83.12268854948609,
			"height": 84.77739352034831,
			"seed": 141864492,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "En9VUI1m",
				"focus": 0.07147544128085154,
				"gap": 5.0070540493206295
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "dot",
			"points": [
				[
					0,
					0
				],
				[
					15.634872195110589,
					25.75400536269177
				],
				[
					83.12268854948609,
					84.77739352034831
				]
			]
		},
		{
			"type": "line",
			"version": 612,
			"versionNonce": 861278252,
			"isDeleted": true,
			"id": "DH-_1s3v4Emxx4OBD6-nJ",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "dotted",
			"roughness": 2,
			"opacity": 100,
			"angle": 0,
			"x": -84.33461598376516,
			"y": -212.58756255697443,
			"strokeColor": "#343a40",
			"backgroundColor": "#7950f2",
			"width": 236.82090629194306,
			"height": 151.9516520231525,
			"seed": 1177439148,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					157.03358894121158,
					-65.04953022567227
				],
				[
					172.78784295971062,
					-55.901946594487136
				],
				[
					187.52560799870645,
					-58.44294818261169
				],
				[
					236.82090629194306,
					71.65611226873285
				],
				[
					226.14874379394655,
					79.27911703310657
				],
				[
					218.5256065131927,
					86.90212179748022
				],
				[
					11.18031864349473,
					29.47557425011837
				],
				[
					10.672074153743125,
					12.196807622997937
				],
				[
					0,
					0
				]
			]
		},
		{
			"id": "yHdrekUMRuQqE_Y6mESKG",
			"type": "ellipse",
			"x": 101.38929748535156,
			"y": -32.808627452016026,
			"width": 53.0167236328125,
			"height": 53.71893310546875,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 918631852,
			"version": 57,
			"versionNonce": 1626560660,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680786468578,
			"link": null,
			"locked": false
		},
		{
			"id": "UhCxGDyjWt7ymh2eBADOE",
			"type": "freedraw",
			"x": -60.46971130371094,
			"y": -310.8831056014301,
			"width": 0.0001,
			"height": 0.0001,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1211915436,
			"version": 4,
			"versionNonce": 1633143572,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680786455716,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0.0001,
					0.0001
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				0.0001,
				0.0001
			]
		},
		{
			"id": "r8r4OFcw_xfNX6W4CRzNv",
			"type": "freedraw",
			"x": -92.42021179199219,
			"y": -214.3294709578754,
			"width": 52.3145751953125,
			"height": 23.87506103515625,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1496129580,
			"version": 73,
			"versionNonce": 2063427756,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680786460514,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					0,
					-0.35107421875
				],
				[
					0.35113525390625,
					-0.35107421875
				],
				[
					0.70220947265625,
					-0.702178955078125
				],
				[
					1.0533447265625,
					-0.702178955078125
				],
				[
					1.75555419921875,
					-1.404388427734375
				],
				[
					2.80889892578125,
					-1.404388427734375
				],
				[
					3.8621826171875,
					-2.106597900390625
				],
				[
					4.91552734375,
					-2.45770263671875
				],
				[
					5.96881103515625,
					-3.159912109375
				],
				[
					7.02215576171875,
					-3.5110321044921875
				],
				[
					8.426513671875,
					-3.8621368408203125
				],
				[
					9.12872314453125,
					-4.2132415771484375
				],
				[
					10.18206787109375,
					-4.915435791015625
				],
				[
					11.23541259765625,
					-5.26654052734375
				],
				[
					12.2886962890625,
					-5.617645263671875
				],
				[
					13.342041015625,
					-5.96875
				],
				[
					14.395263671875,
					-6.67095947265625
				],
				[
					15.44866943359375,
					-7.0220489501953125
				],
				[
					16.15087890625,
					-7.3731536865234375
				],
				[
					17.20416259765625,
					-8.075393676757812
				],
				[
					18.2574462890625,
					-8.426498413085938
				],
				[
					19.310791015625,
					-9.128707885742188
				],
				[
					20.01300048828125,
					-9.128707885742188
				],
				[
					21.0662841796875,
					-9.479782104492188
				],
				[
					21.76849365234375,
					-10.181991577148438
				],
				[
					22.82177734375,
					-10.533096313476562
				],
				[
					23.8751220703125,
					-10.884201049804688
				],
				[
					24.928466796875,
					-11.235305786132812
				],
				[
					25.63067626953125,
					-11.586410522460938
				],
				[
					26.6839599609375,
					-11.937515258789062
				],
				[
					28.08837890625,
					-12.639739990234375
				],
				[
					29.1417236328125,
					-12.9908447265625
				],
				[
					30.19500732421875,
					-13.341949462890625
				],
				[
					31.248291015625,
					-14.044143676757812
				],
				[
					32.3016357421875,
					-14.395248413085938
				],
				[
					33.35491943359375,
					-15.097457885742188
				],
				[
					34.40826416015625,
					-15.097457885742188
				],
				[
					35.1104736328125,
					-15.799667358398438
				],
				[
					36.163818359375,
					-16.150772094726562
				],
				[
					36.865966796875,
					-16.150772094726562
				],
				[
					37.91925048828125,
					-16.85296630859375
				],
				[
					38.62152099609375,
					-16.85296630859375
				],
				[
					39.6748046875,
					-17.555206298828125
				],
				[
					40.37701416015625,
					-17.906280517578125
				],
				[
					41.43035888671875,
					-18.25738525390625
				],
				[
					42.132568359375,
					-18.608489990234375
				],
				[
					43.18585205078125,
					-18.9595947265625
				],
				[
					43.8880615234375,
					-19.66180419921875
				],
				[
					44.59027099609375,
					-19.66180419921875
				],
				[
					45.29248046875,
					-20.364013671875
				],
				[
					45.6435546875,
					-20.364013671875
				],
				[
					46.34576416015625,
					-20.715118408203125
				],
				[
					47.0479736328125,
					-21.06622314453125
				],
				[
					47.39910888671875,
					-21.417327880859375
				],
				[
					47.750244140625,
					-21.417327880859375
				],
				[
					48.101318359375,
					-21.7684326171875
				],
				[
					48.45245361328125,
					-22.119537353515625
				],
				[
					48.803466796875,
					-22.119537353515625
				],
				[
					49.1546630859375,
					-22.119537353515625
				],
				[
					49.50567626953125,
					-22.47064208984375
				],
				[
					49.85687255859375,
					-22.821746826171875
				],
				[
					50.2078857421875,
					-23.1728515625
				],
				[
					50.91009521484375,
					-23.1728515625
				],
				[
					51.26129150390625,
					-23.1728515625
				],
				[
					51.26129150390625,
					-23.523956298828125
				],
				[
					51.6123046875,
					-23.523956298828125
				],
				[
					51.6123046875,
					-23.87506103515625
				],
				[
					51.9635009765625,
					-23.87506103515625
				],
				[
					52.3145751953125,
					-23.87506103515625
				],
				[
					52.3145751953125,
					-23.87506103515625
				]
			],
			"pressures": [],
			"simulatePressure": true,
			"lastCommittedPoint": [
				52.3145751953125,
				-23.87506103515625
			]
		},
		{
			"id": "PCqmDlIv30KwbBkuBDSvK",
			"type": "arrow",
			"x": -92.77128601074219,
			"y": -226.6180909529926,
			"width": 152.3792724609375,
			"height": 63.54986572265625,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1282131988,
			"version": 88,
			"versionNonce": 840527788,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680786468578,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					152.3792724609375,
					-63.54986572265625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": {
				"elementId": "4OG5SBqnDuyY0m1u2WDYG",
				"focus": -1.182038446138849,
				"gap": 10.273163731550266
			},
			"endBinding": {
				"elementId": "sjfISESfaBrJDrpe6k2OL",
				"focus": 0.6763993968216127,
				"gap": 12.584112338445205
			},
			"startArrowhead": null,
			"endArrowhead": "dot"
		},
		{
			"id": "01oKsvsc",
			"type": "text",
			"x": 42.48378151290084,
			"y": -381.15437365718367,
			"width": 10,
			"height": 25,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 21096596,
			"version": 5,
			"versionNonce": 446536364,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680786584893,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "pZLaqcXA7PNeMxnB20s5T",
			"originalText": "",
			"lineHeight": 1.25
		},
		{
			"id": "LskAnb5eroSOT_zRO0MN8",
			"type": "arrow",
			"x": 74.96526556620819,
			"y": -369.46587062160523,
			"width": 12.9908447265625,
			"height": 0.70220947265625,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1478019116,
			"version": 242,
			"versionNonce": 203344532,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680786570654,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					12.9908447265625,
					0.70220947265625
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": "triangle"
		},
		{
			"id": "rftVyuAW",
			"type": "text",
			"x": 42.57585195517788,
			"y": -381.15437365718367,
			"width": 10,
			"height": 25,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 333960084,
			"version": 4,
			"versionNonce": 1574952876,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680786584893,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "pZLaqcXA7PNeMxnB20s5T",
			"originalText": "",
			"lineHeight": 1.25
		},
		{
			"id": "VQ2jOxiw",
			"type": "text",
			"x": 42.575867961861185,
			"y": -381.15437365718367,
			"width": 10,
			"height": 25,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 612091308,
			"version": 4,
			"versionNonce": 1179499284,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680786582949,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "pZLaqcXA7PNeMxnB20s5T",
			"originalText": "",
			"lineHeight": 1.25
		},
		{
			"id": "BlljVxM7",
			"type": "text",
			"x": 42.667938404138226,
			"y": -381.15437365718367,
			"width": 10,
			"height": 25,
			"angle": 0,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "transparent",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1383347604,
			"version": 3,
			"versionNonce": 212525204,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680786572546,
			"link": null,
			"locked": false,
			"text": "",
			"rawText": "",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "center",
			"verticalAlign": "middle",
			"containerId": "pZLaqcXA7PNeMxnB20s5T",
			"originalText": "",
			"lineHeight": 1.25
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#5f3dc4",
		"currentItemBackgroundColor": "transparent",
		"currentItemFillStyle": "cross-hatch",
		"currentItemStrokeWidth": 0.5,
		"currentItemStrokeStyle": "dashed",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 356.56074076132666,
		"scrollY": 619.4978058687809,
		"zoom": {
			"value": 1.2550383242430059
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%