---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
1 ^rSnD0F3m

Face ^En9VUI1m

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.22",
	"elements": [
		{
			"type": "ellipse",
			"version": 675,
			"versionNonce": 401384980,
			"isDeleted": false,
			"id": "4OG5SBqnDuyY0m1u2WDYG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -121.9542236328125,
			"y": -217.1609115600586,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 44.23913574218751,
			"height": 44.23911364326004,
			"seed": 217944236,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680785456678,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 733,
			"versionNonce": 1494664084,
			"isDeleted": false,
			"id": "v5T96D5mpEbGBcH6NM1lv",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 134.3521728515625,
			"y": -139.91793060302734,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 48.45236206054688,
			"height": 48.45236206054688,
			"seed": 1816210604,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1680785459115,
			"link": null,
			"locked": false
		},
		{
			"type": "text",
			"version": 2,
			"versionNonce": 1548831916,
			"isDeleted": false,
			"id": "rSnD0F3m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -59.87896728515625,
			"y": -179.87041091918945,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffffff",
			"width": 5.4199981689453125,
			"height": 25,
			"seed": 827332244,
			"groupIds": [],
			"roundness": null,
			"boundElements": [],
			"updated": 1680784238906,
			"link": null,
			"locked": false,
			"fontSize": 20,
			"fontFamily": 1,
			"text": "1",
			"rawText": "1",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "1",
			"lineHeight": 1.25
		},
		{
			"type": "line",
			"version": 156,
			"versionNonce": 485090452,
			"isDeleted": false,
			"id": "lJONppCiyQo8Gw_dagu6f",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -79.96942138671875,
			"y": -183.7921028137207,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"width": 217.6845703125,
			"height": 59.687713623046875,
			"seed": 987022380,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680784255115,
			"link": null,
			"locked": false,
			"startBinding": null,
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": null,
			"points": [
				[
					0,
					0
				],
				[
					217.6845703125,
					59.687713623046875
				]
			]
		},
		{
			"type": "arrow",
			"version": 2101,
			"versionNonce": 2005533588,
			"isDeleted": false,
			"id": "FfbVKRvroF9T-LM-YTIZX",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"angle": 0,
			"x": -37.85308409981127,
			"y": -283.49780842917426,
			"strokeColor": "#343a40",
			"backgroundColor": "#ffffff",
			"width": 84.22113458132331,
			"height": 84.77739352034831,
			"seed": 141864492,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680785581295,
			"link": null,
			"locked": false,
			"startBinding": {
				"elementId": "En9VUI1m",
				"focus": 0.07147544128085154,
				"gap": 5.0070540493206295
			},
			"endBinding": null,
			"lastCommittedPoint": null,
			"startArrowhead": null,
			"endArrowhead": "dot",
			"points": [
				[
					0,
					0
				],
				[
					16.733318226947816,
					25.75400536269177
				],
				[
					84.22113458132331,
					84.77739352034831
				]
			]
		},
		{
			"type": "text",
			"version": 946,
			"versionNonce": 1243045548,
			"isDeleted": false,
			"id": "En9VUI1m",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -90.94021041713765,
			"y": -331.76227824997926,
			"strokeColor": "#5f3dc4",
			"backgroundColor": "#ffffff",
			"width": 79.23396301269531,
			"height": 43.257415771484354,
			"seed": 1646571436,
			"groupIds": [],
			"roundness": null,
			"boundElements": [
				{
					"id": "FfbVKRvroF9T-LM-YTIZX",
					"type": "arrow"
				}
			],
			"updated": 1680785577744,
			"link": null,
			"locked": false,
			"fontSize": 34.605932617187484,
			"fontFamily": 1,
			"text": "Face",
			"rawText": "Face",
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Face",
			"lineHeight": 1.25
		},
		{
			"id": "TxNhKbTrm_KXfkdhAj0Oc",
			"type": "line",
			"x": 156.04373670367892,
			"y": -140.58152146132244,
			"width": 54.377389813739114,
			"height": 132.1319058939709,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"fillStyle": "hachure",
			"strokeWidth": 2,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1419957932,
			"version": 159,
			"versionNonce": 679169684,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680785464741,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-54.377389813739114,
					-132.1319058939709
				]
			],
			"lastCommittedPoint": [
				-50.311787272739764,
				-122.98430017672246
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"type": "ellipse",
			"version": 878,
			"versionNonce": 1080875156,
			"isDeleted": false,
			"id": "sjfISESfaBrJDrpe6k2OL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 72.35182244557637,
			"y": -310.6729722922383,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"width": 39.30475634329844,
			"height": 39.30475634329844,
			"seed": 655664532,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [],
			"updated": 1680785451183,
			"link": null,
			"locked": false
		},
		{
			"id": "MHZieau-yDxsOsAC58KqC",
			"type": "line",
			"x": -85.3511049632684,
			"y": -214.6203859135374,
			"width": 157.5419217752166,
			"height": 68.60691036298334,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "transparent",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 2,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 889023532,
			"version": 119,
			"versionNonce": 1150898476,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680785475826,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					157.5419217752166,
					-68.60691036298334
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "DH-_1s3v4Emxx4OBD6-nJ",
			"type": "line",
			"x": -84.33461598376516,
			"y": -212.58756255697443,
			"width": 236.82090629194306,
			"height": 151.9516520231525,
			"angle": 0,
			"strokeColor": "#343a40",
			"backgroundColor": "#7950f2",
			"fillStyle": "cross-hatch",
			"strokeWidth": 1,
			"strokeStyle": "dotted",
			"roughness": 2,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1177439148,
			"version": 608,
			"versionNonce": 124971028,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680785531893,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					157.03358894121158,
					-65.04953022567227
				],
				[
					172.78784295971062,
					-55.901946594487136
				],
				[
					187.52560799870645,
					-58.44294818261169
				],
				[
					236.82090629194306,
					71.65611226873285
				],
				[
					226.14874379394655,
					79.27911703310657
				],
				[
					218.5256065131927,
					86.90212179748022
				],
				[
					11.18031864349473,
					29.47557425011837
				],
				[
					10.672074153743125,
					12.196807622997937
				],
				[
					0,
					0
				]
			],
			"lastCommittedPoint": [
				0.5080678012448345,
				3.0492019057494986
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#343a40",
		"currentItemBackgroundColor": "#7950f2",
		"currentItemFillStyle": "cross-hatch",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "dotted",
		"currentItemRoughness": 2,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "dot",
		"scrollX": 287.0269887159278,
		"scrollY": 569.0180710005488,
		"zoom": {
			"value": 1.3817572486732046
		},
		"currentItemRoundness": "sharp",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%