---

excalidraw-plugin: parsed
tags: [excalidraw]

---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==


# Text Elements
1 ^rSnD0F3m

Vertex ^En9VUI1m

%%
# Drawing
```json
{
	"type": "excalidraw",
	"version": 2,
	"source": "https://github.com/zsviczian/obsidian-excalidraw-plugin/releases/tag/1.8.22",
	"elements": [
		{
			"type": "ellipse",
			"version": 673,
			"versionNonce": 1235916564,
			"isDeleted": false,
			"id": "4OG5SBqnDuyY0m1u2WDYG",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": -121.9542236328125,
			"y": -217.1609115600586,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 44.23913574218751,
			"height": 44.23911364326004,
			"seed": 217944236,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": [
				{
					"id": "FfbVKRvroF9T-LM-YTIZX",
					"type": "arrow"
				}
			],
			"updated": 1680784259182,
			"link": null,
			"locked": false
		},
		{
			"type": "ellipse",
			"version": 730,
			"versionNonce": 1417220396,
			"isDeleted": false,
			"id": "sjfISESfaBrJDrpe6k2OL",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"angle": 0,
			"x": 134.3521728515625,
			"y": -139.91793060302734,
			"strokeColor": "#000000",
			"backgroundColor": "#000000",
			"width": 48.45236206054688,
			"height": 48.45236206054688,
			"seed": 655664532,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"boundElements": null,
			"updated": 1680784219833,
			"link": null,
			"locked": false
		},
		{
			"id": "rSnD0F3m",
			"type": "text",
			"x": -59.87896728515625,
			"y": -179.87041091918945,
			"width": 5.4199981689453125,
			"height": 25,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffffff",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 827332244,
			"version": 2,
			"versionNonce": 1548831916,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680784238906,
			"link": null,
			"locked": false,
			"text": "1",
			"rawText": "1",
			"fontSize": 20,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "1",
			"lineHeight": 1.25
		},
		{
			"id": "lJONppCiyQo8Gw_dagu6f",
			"type": "line",
			"x": -79.96942138671875,
			"y": -183.7921028137207,
			"width": 217.6845703125,
			"height": 59.687713623046875,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 987022380,
			"version": 156,
			"versionNonce": 485090452,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680784255115,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					217.6845703125,
					59.687713623046875
				]
			],
			"lastCommittedPoint": [
				217.6845703125,
				59.687713623046875
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "FfbVKRvroF9T-LM-YTIZX",
			"type": "arrow",
			"x": 16.797438031740796,
			"y": -225.73540318348597,
			"width": 108.70435941845966,
			"height": 16.150802612304688,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 2028483092,
			"version": 989,
			"versionNonce": 1816963116,
			"isDeleted": false,
			"boundElements": null,
			"updated": 1680784304124,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					-46.20789945752201,
					-7.2112864222269195
				],
				[
					-108.70435941845966,
					8.939516190077768
				]
			],
			"lastCommittedPoint": [
				-18.25732421875,
				58.985504150390625
			],
			"startBinding": null,
			"endBinding": {
				"elementId": "4OG5SBqnDuyY0m1u2WDYG",
				"focus": -0.8625394469958502,
				"gap": 1.0344619649327207
			},
			"startArrowhead": null,
			"endArrowhead": "arrow"
		},
		{
			"id": "En9VUI1m",
			"type": "text",
			"x": 16.23321533203125,
			"y": -237.86207962036133,
			"width": 109.61276245117188,
			"height": 43.257415771484354,
			"angle": 0,
			"strokeColor": "#000000",
			"backgroundColor": "#ffffff",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": null,
			"seed": 1646571436,
			"version": 593,
			"versionNonce": 283446804,
			"isDeleted": false,
			"boundElements": [],
			"updated": 1680784367524,
			"link": null,
			"locked": false,
			"text": "Vertex",
			"rawText": "Vertex",
			"fontSize": 34.605932617187484,
			"fontFamily": 1,
			"textAlign": "left",
			"verticalAlign": "top",
			"containerId": null,
			"originalText": "Vertex",
			"lineHeight": 1.25
		},
		{
			"id": "2KFfd1uxDejkp2tDBwORg",
			"type": "line",
			"x": -153.70135498046875,
			"y": -187.30311965942383,
			"width": 228.9200439453125,
			"height": 35.110382080078125,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffffff",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 1380876820,
			"version": 49,
			"versionNonce": 296977940,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680784211236,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					228.9200439453125,
					35.110382080078125
				]
			],
			"lastCommittedPoint": null,
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		},
		{
			"id": "y01SYNSjnYiaBSedDuRCf",
			"type": "line",
			"x": -78.56500244140625,
			"y": -184.49431228637695,
			"width": 582.8328857421875,
			"height": 205.74705505371094,
			"angle": 0,
			"strokeColor": "#ffffff",
			"backgroundColor": "#ffffff",
			"fillStyle": "hachure",
			"strokeWidth": 1,
			"strokeStyle": "solid",
			"roughness": 1,
			"opacity": 100,
			"groupIds": [],
			"roundness": {
				"type": 2
			},
			"seed": 782643244,
			"version": 362,
			"versionNonce": 2093121940,
			"isDeleted": true,
			"boundElements": null,
			"updated": 1680784240901,
			"link": null,
			"locked": false,
			"points": [
				[
					0,
					0
				],
				[
					214.875732421875,
					63.900970458984375
				],
				[
					-367.9571533203125,
					-141.84608459472656
				],
				[
					18.9595947265625,
					4.91546630859375
				]
			],
			"lastCommittedPoint": [
				18.9595947265625,
				4.91546630859375
			],
			"startBinding": null,
			"endBinding": null,
			"startArrowhead": null,
			"endArrowhead": null
		}
	],
	"appState": {
		"theme": "dark",
		"viewBackgroundColor": "#ffffff",
		"currentItemStrokeColor": "#000000",
		"currentItemBackgroundColor": "#ffffff",
		"currentItemFillStyle": "hachure",
		"currentItemStrokeWidth": 1,
		"currentItemStrokeStyle": "solid",
		"currentItemRoughness": 1,
		"currentItemOpacity": 100,
		"currentItemFontFamily": 1,
		"currentItemFontSize": 20,
		"currentItemTextAlign": "left",
		"currentItemStartArrowhead": null,
		"currentItemEndArrowhead": "arrow",
		"scrollX": 419.72857666015625,
		"scrollY": 613.7959747314453,
		"zoom": {
			"value": 1
		},
		"currentItemRoundness": "round",
		"gridSize": null,
		"colorPalette": {},
		"currentStrokeOptions": null,
		"previousGridSize": null
	},
	"files": {}
}
```
%%