>[!cite] Traversable Graphs
>A Traversable graph can be traversed using each [[Edge]] only **once**.
>
>a Graph is traversable if it is [[Connected Graph|Connected]] and it is [[Eulerian graph|Eulerian]] or [[Eulerian graph|Semi-Eulerian]].


